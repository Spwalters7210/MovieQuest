<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="detective office wall and floor" tilewidth="16" tileheight="16" tilecount="60" columns="10">
 <image source="Neko Office Asset Pack/neko-office-tileset.png" width="160" height="96"/>
</tileset>
